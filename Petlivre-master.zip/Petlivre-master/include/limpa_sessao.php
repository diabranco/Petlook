<?php
// APAGA OS DADOS DAS VARIVEIS

unset($_SESSION["rad_sel_visl"]);
unset($_SESSION["rad_animal_clie"]);
unset($_SESSION["checa_retorno"]);
unset($_SESSION["rad_forne"]);
unset($_SESSION["rad_clie"]);
unset($_SESSION["retorno"]);


?>