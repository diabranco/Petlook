<?php

define(TITLE, 'PetLivre - Sistema para Gerenciamento de Petshop');

?>
