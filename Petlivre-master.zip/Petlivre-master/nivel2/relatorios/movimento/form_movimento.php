<form name="form" method="post" action="movimento.php">
<table width="75%" border="1" align="center">
  <tr>
    <td><div align="center"><font size="4"><strong>Movimento</strong></font></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">Data inicial:
          
		  <input name="txt_data_inicial" type="text" id="txt_data_inicial"  onkeyup="formata(this);" value="" size="8" maxlength="10" tabindex="13" />
		  </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">Data final:
          		  <input name="txt_data_final" type="text" id="txt_data_final"  onkeyup="formata(this);" value="" size="8" maxlength="10" tabindex="13" />
</div></td>
  </tr>
  <tr>
    <td height="50"><div align="center">
      <input type="submit" name="Submit" value="Enviar">
</div></td>
  </tr>
</table>
<div align="center"></div>
</form>
