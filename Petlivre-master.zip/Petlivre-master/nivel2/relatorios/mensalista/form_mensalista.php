<form name="form" method="post" action="lista_total_mensal.php">
<table width="75%" border="1" align="center">
  <tr>
    <td><div align="center"><font size="4"><strong>Mensalista</strong></font></div></td>
  </tr>
  <tr>
    <td height="24">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">Informe o m&ecirc;s:
          
  
        <select name="sel_mes" id="sel_mes">
      <option></option>  
      <option value="1">Janeiro</option>
      <option value="2">Fevereiro</option>
      <option value="3">Mar�o</option>
      <option value="4">Abril</option>
      <option value="5">Maio</option>
      <option value="6">Junho</option>
      <option value="7">Julho</option>
      <option value="8">Agosto</option>
      <option value="9">Setembro</option>
      <option value="10">Outubro</option>
      <option value="11">Novembro</option>
      <option value="12">Dezembro</option>
  </select>
    </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  
  <tr>
    <td height="50"><div align="center">
      <input type="submit" name="Submit" value="Enviar">
</div></td>
  </tr>
</table>
<div align="center"></div>
</form>