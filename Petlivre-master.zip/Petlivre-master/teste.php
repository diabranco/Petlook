<?php @mail("celostad@bol.com.br","titulo de teste","corpo do teste","From: marcelo@maypet.com.br");
?> 

