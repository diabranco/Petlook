<?php require_once("visitantes_online.php"); ?>

<html>

<head>

<title>Loja | Petshop | MayPet - Cl&iacute;nica Veterin&aacute;ria</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" href="config.css" type="text/css">

<meta name="title" content="Loja | Petshop | MayPet - Clinica Veterinaria" />

<meta name="author" content="Marcelo Tadim" />

<meta name="url" content="http://www.maypet.com.br" />

<meta name="copyright" content="Artigos disponiveis sob uma licenca Creative Commons, salvo indicativo do contrario" />


<meta name="keywords" content="maypet,may pet,www.maypet.com.br,veterinario,veterinaria,petshop,pet shop,loja virtual,loja,racao,racoes,acessorios,clinica,cl�nica,clinica veterinaria, banho,loja veterinaria virtual,loja virtual veterinaria,cl�nicas veterinarias em diadema,loja veterinaria,clinica veterinaria taboao diadema,cl�nica pet shop,cl�nica veterin�ria e pet shop,cl�nica veterin�ria pet shop,maypet cl�nica veterin�ria"/><meta name="dc.language" content="pt" />

<meta name="rating" content="general" />

<meta name="robots" content="index,follow" />

<meta name="revisit-after" content="1 days" />

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">

</script>

</head>

<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div id="google_translate_element"></div><script>
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'pt'
  }, 'google_translate_element');
}
</script><script src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<table width="776" height="959" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr valign="top"> 

    <td colspan="3"><?php include ("topo.php"); ?></td>

  </tr>

  <tr> 

    <td width="198" height="7" valign="top"></td>

    <td width="16" height="7" valign="top"></td>

    <td width="565" height="7" valign="top"></td>

  </tr>

  <tr>

    <td height="597" valign="top"><?php include "menu_dir.php"; ?></td>

    <td width="16" valign="top"></td>

    <td width="565" height="597" valign="top"><table width="565" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td width="565" height="45" background="imagens/loja/layout_loja_cima_565x10.jpg">&nbsp;</td>

      </tr>

      <tr>

        <td width="565" height="221" align="center" background="imagens/layout_principal_meio_565x1.jpg"><table width="550" height="568" border="0" cellpadding="0" cellspacing="0">

          <tr>

            <td valign="top" class="style5"><div align="center"></div></td>

          </tr>

          <tr>

            <td height="549"><table width="555" border="0" cellspacing="1" cellpadding="1">

              <tr>

                <td height="10" colspan="2"><div align="center">

                  <table width="531" border="0" cellspacing="1" cellpadding="1">

                    <tr>

                      <td width="339"><p align="justify" class="style5">Venda de ra&ccedil;&otilde;es para c&atilde;es, gatos, peixes, aves e roedores. Trabalhamos com os melhores produtos do mercado pet. </p>

                          <div align="justify">

                            <ul>

                              <li class="style5">                          V&aacute;rios acess&oacute;rios;</li>

                              <li class="style5">Roupinhas;</li>

                              <li class="style5">Coleiras;  </li>

                            </ul>

                          </div></td>

                        <td width="185"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="185" height="139">

                          <param name="movie" value="imagens/loja/loja3.swf">

                          <param name="quality" value="high">

                          <embed src="imagens/loja/loja3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="185" height="139"></embed>

                          </object></td>

                      </tr>

                  </table>

                </div></td>

                </tr>

              

              <tr>

                <td height="10" colspan="2"></td>

              </tr>

              <tr>

                <td height="10" colspan="2"><div align="center">

                  <table width="531" border="0" cellspacing="1" cellpadding="1">

                    <tr>

                      <td width="185"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="185" height="139">

                          <param name="movie" value="imagens/loja/loja1.swf">

                          <param name="quality" value="high">

                          <embed src="imagens/loja/loja1.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="185" height="139"></embed>

                        </object></td>

                        <td width="344"><div align="justify">

                          <ul>

                            <li class="style5">Casinhas de madeira e pl&aacute;stico;</li>

                            <li class="style5">Casinha de transporte;</li>

                            <li class="style5">Shampoo;</li>

                            <li class="style5">Perfumes;</li>

                            <li class="style5"><span class="style5">Arranhadores de gato;</span> </li>

                            </ul>

                        </div></td>

                      </tr>

                  </table>

                </div></td>

                </tr>

              <tr>

                <td height="10" colspan="2"></td>

                </tr>

              <tr>

                <td height="10" colspan="2"><table width="550" border="0" cellspacing="1" cellpadding="1">

                  <tr>

                    <td width="358"><ul>

                      <li class="style5">Caminhas;</li>

                      <li class="style5">Comedouros;</li>

                      <li class="style5">Petiscos;</li>

                      <li class="style5">e muito mais... </li>

                      </ul>                      </td>

                    <td width="185"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="185" height="139">

                      <param name="movie" value="imagens/loja/loja2.swf">

                      <param name="quality" value="high">

                      <embed src="imagens/loja/loja2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="185" height="139"></embed>

                    </object></td>

                  </tr>

                </table></td>

                </tr>

              

              <tr>

                <td height="10" colspan="2" class="style5"></td>

              </tr>

              <tr>

                <td width="244" height="10" class="style5"><div align="center"><img src="imagens/loja/Untitled-1.jpg" width="237" height="300"></div></td>

                <td width="304" height="10" class="style5"><div align="center">

                  <p>Estamos localizados na Rua Pol&ocirc;nia, 33<br>

                    Tabo&atilde;o - Diadema - SP<br>

                    <br>

                    ( Pr&oacute;ximo ao supermercado Compre Bem)</p>

                  <p>Para visualizar o mapa do nosso endere&ccedil;o,<br> 

                    <a href="http://maps.google.com.br/maps?q=maypet%2Brua%2Bpolonia,33%2Bdiadema&hl=pt-BR&gl=br&ie=UTF8&view=map&cid=2995259457147553641&ved=0CBcQpQY&ei=eqdDS5XBFp-yNcrFuIsN&hq=maypet%2Brua%2Bpolonia,33%2Bdiadema&hnear=&ll=-23.668915,-46.609991&spn=0.00849,0.021973&z=16" target="_blank">clique aqui.</a></p>

                </div></td>

              </tr>

              

              

            </table></td>

          </tr>

        </table></td>

      </tr>

      <tr>

        <td width="565" height="14" background="imagens/layout_produtos_rodape.jpg"></td>

      </tr>

    </table></td>

  </tr>

  

  <tr>

    <td height="71" colspan="3" valign="top"><? include("rodape.php"); ?></td>

  </tr>

</table>



</body>

</html>



