<html>
<head>
<title>Pet Livre - Sistema Gerenciamento Petshop - Acesso Restrito</title>
<link rel="stylesheet" href="css/config.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.style6 {font-size: 11px; font-weight: bold; color: #555; }
.style12 {font-size: 11px; font-weight: bold; color: #555; font-family: Verdana, sans-serif; }
.style13 {color: #555; font-family: Verdana, sans-serif; }
.style15 {font-size: 12px; font-weight: bold; color: #8BA1DA; font-family: Verdana, sans-serif; }
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" >
<table width="735" border="0" cellpadding="0" cellspacing="2" align="center" height="377">
  <tr>
    <td height="312" valign="middle"><div align="center">
      <form method="post" action="login.php">
        <table width="300" height="285" border="1" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="103"><table width="300" height="110" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td height="100"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b><img src="imagens/titulo_pet_livre.jpg" width="205" height="101"></b></font></div></td>
                </tr>
            </table></td>
          </tr>
          
          <tr>
            <td height="135"><table width="300" height="133" border="0" cellpadding="1" cellspacing="1" bgcolor="#F7FCF8">
              <tr>
                <td height="131" valign="middle"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b><font face="Verdana" size="2"><img src="imagens/chave2.gif" width="35" height="34"></font></b></font></b></font><font face="Verdana" size="2"><br>
                    </font></b></font><font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b></b></font><font face="Verdana" size="2" color="#FF0000">.: 
                      Acesso Restrito:.</font></b></font><br>
                  </div>
                    <table width="191" border="0" cellspacing="0" cellpadding="0" align="center" height="60">
                      <tr>
                        <td width="30%" height="27" class="style6"><div align="right" class="body style13">
                            <div align="right"><font size="2">Usu&aacute;rio:</font></div>
                        </div></td>
                        <td width="51%"><div align="left">
                            <input name="login" type="text" onfocus size="10" maxlength="20">
                        </div></td>
                        <td width="19%" height="27">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="30%" height="31" valign="top" class="style6"><div align="right" class="style13"><font size="2">Senha:</font></div></td>
                        <td width="51%" valign="top"><div align="left">
                            <input name="senha" type="password" value="" size="10" maxlength="15">
                            <br>
                        </div></td>
                        <td width="19%" height="31" valign="top"><input type="image" border="0" name="imageField" src="imagens/SETA.GIF" width="30" height="31" alt="Entrar"></td>
                      </tr>
                  </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="30"><table width="300" height="10" border="0" cellpadding="0" cellspacing="0">
                
                <tr>
                  <td height="10" valign="middle"><div align="center"><font color="#999999" size="2">Melhor 
    visualizado na resolu&ccedil;&atilde;o: 800X600</font></div></td>
                </tr>
              </table>
              <div align="center"></div></td>
          </tr>
        </table>
      </form>
    </div>      </td>
  </tr>
  <tr>
    <td height="65" valign="bottom"><div align="center"><a href="mailto:celostad@bol.com.br"><img src="imagens/logo_livresys_peq.jpg" width="116" height="52" border="0"></a></div></td>
  </tr>
  <tr>
    <td height="25" valign="bottom"><div align="center"><a href="mailto:celostad@bol.com.br"></a><img src="imagens/powered.jpg" width="254" height="15"></div></td>
  </tr>
</table>
</body>
</html>
