<script>
alert ("                             Aten��o ! \n\n� necess�rio primeiro fechar o caixa do dia ANTERIOR!\n\n") 
window.location = "index_finaliza_caixa.php";

</script>
