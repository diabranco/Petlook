<script>
alert ("          Aten��o!\n\nItem n�o selecionado.\n\n") 
window.location = "cad_clie_bairro.php";
</script>
