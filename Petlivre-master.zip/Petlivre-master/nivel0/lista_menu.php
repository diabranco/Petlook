<style type="text/css">
<!--
.style1 {
	font-size: 20px;
	font-weight: bold;
	color: #FFFFFF;
}
-->
</style>