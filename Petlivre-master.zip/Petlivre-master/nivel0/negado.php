<html>
<head>
<title>Pet Livre - Sistema de gerenciamento PetShop  (ACESSO NEGADO) </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body bgcolor="#FFFFFF" text="#000000" >
<p>&nbsp;</p>
<form method="get" action="../login.asp">
  <div align="center">
    <table width="44%" border="0" cellspacing="0" cellpadding="0" height="332">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td background="imagens/fundo2.gif" height="306"> 
          <div align="center">
            <p><font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b><font face="Verdana" size="2"><img src="../imagens/NAO.GIF" width="36" height="32"></font></b></font></p>
            <p><font color="#FF0000"><strong>Usu&aacute;rio/senha incorreto</strong></font> <font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><b><font face="Verdana" size="2"><br>
              </font></b><font face="Verdana" size="2"><br>
                <font size="1" color="#333333"> IP LOGADO</font><font color="#333333">:</font><font color="#333333"><b> <font face="Verdana, Arial, Helvetica, sans-serif" size="5" color="#000000"><font face="Verdana" size="2"><font color="#333333"><b><font face="Verdana" size="2">
                <?
  echo $ip = getenv("REMOTE_ADDR");
?>
                </font></b></font></font></font></b> <br>
                </font></font></font><br>
                <a href="../index.php" style=text-decoration="none"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Tentar 
            novo login</font></a></p>
          </div>
        </td>
      </tr>
    </table>
    <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
  </div>
  <p></p>
</form>
</body>
</html>
