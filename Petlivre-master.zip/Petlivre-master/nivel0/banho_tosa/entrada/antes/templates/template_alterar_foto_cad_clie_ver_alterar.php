<table width="180" height="180" border="1" cellpadding="0" cellspacing="0" bordercolor="#7F9DB9" bgcolor="#FFFFFF">
  <tr>
    <td height="135"><p align="center">
      <input name="balizador" type="file" id="balizador" size="10" />
      <br />
    </p></td>
  </tr>
  <tr>
    <td height="35"><div align="center">
      <input type="button" name="Button" value="Anexar Foto" onclick="javascript: anexa_foto_cad_clie_ver_alterar();" />
      &nbsp;&nbsp;
      <input type="button" name="Button" value="Voltar" onclick="javascript:alterar_foto_ver_altera_cad_clie();" />
    </div></td>
  </tr>
</table>
