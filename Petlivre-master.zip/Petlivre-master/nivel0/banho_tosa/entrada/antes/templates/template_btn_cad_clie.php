<table width="130" height="60" border="0" cellpadding="2" cellspacing="2">
  <tr>
    <td width="95"><div align="center"><a href="javascript:gravar_clie();"><img src="../../../imagens/salvar1.gif" alt="Gravar" width="39" height="41" border="0" /></a></div></td>
    <td width="102"><div align="center">
<?
 if ($checa_retorno==1){ echo "<a href=\"javascript:chk_dados_sair_clie();\">";}
 if ($checa_retorno==10){ echo "<a href=\"javascript:chk_dados_sair_clie();\">";}
?>
	<img src="../../../imagens/voltar1.gif" alt="Voltar" width="48" height="37" border="0" /></a></div></td>
  </tr>
</table>
