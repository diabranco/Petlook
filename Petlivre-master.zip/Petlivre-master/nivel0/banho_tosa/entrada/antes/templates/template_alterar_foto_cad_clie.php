<table width="180" height="170" border="1" cellpadding="0" cellspacing="0" bordercolor="#7F9DB9" bgcolor="#FFFFFF">
  <tr>
    <td height="135"><p align="center">
      <input name="balizador" type="file" id="balizador" size="10" />
      <br />
    </p></td>
  </tr>
  <tr>
    <td height="35"><div align="center">
      <input type="button" name="Button" value="Anexar Foto" onclick="javascript: valida_campos();" />
      &nbsp;&nbsp;
      <input type="button" name="Button" value="Voltar" onclick="javascript:voltar_cad_clie_foto();" />
    </div></td>
  </tr>
</table>
