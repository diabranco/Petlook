<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="utf-8"/>
        <title></title>
    </head>
    <body>
        
    </body>
</html>


<?php
    include("conexao.php");
    //echo('Gerenciamento dos donos de pet.');

    
    $name=mysql_real_escape_string(htmlspecialchars(trim($_POST['name'])));
    $email=mysql_real_escape_string(htmlspecialchars(trim($_POST['email'])));
    $tel = mysql_real_escape_string(htmlspecialchars(trim($_POST['telefone'])));
    $cep =mysql_real_escape_string(htmlspecialchars(trim($_POST['cep'])));
    $rua =mysql_real_escape_string(htmlspecialchars(trim($_POST['rua'])));
    $no =mysql_real_escape_string(htmlspecialchars(trim($_POST['no'])));
    $bairro =mysql_real_escape_string(htmlspecialchars(trim($_POST['bairro'])));
    $estado =mysql_real_escape_string(htmlspecialchars(trim($_POST['estado'])));
    $cidade =mysql_real_escape_string(htmlspecialchars(trim($_POST['cidade'])));
    $senha =md5($_POST['senha']); 
    $login=mysql_num_rows(mysql_query("select * from `cad_dono` where `CAD_DONO_TEL`='$tel';"));
    
    if($login!=0)
    {
    //echo($login);
    
    echo ("<script type=text/javascript> alert('Pessoa já cadastrada no Petlook!');</script>");
    echo("<script type=text/javascript>javascript:history.back();</script>");
    
    }
    else
    {
    $q=mysql_query("insert into `cad_dono` (`idCAD_DONO`,
        `CAD_DONO_NOME`,
        `CAD_DONO_EMAIL`,
        `CAD_DONO_TEL`,
        `CAD_DONO_CEP`,
        `CAD_DONO_RUA`,
        `CAD_DONO_NUMERO`,
        `CAD_DONO_BAIRRO`,
        `CAD_DONO_ESTADO`,
        `CAD_DONO_CIDADE`,
        `CAD_DONO_SENHA`) values 
        (NULL,'$name','$email','$tel','$cep','$rua','$no','$bairro','$estado','$cidade','$senha');");
    
    if($q)
    {
    echo ("<script type=text/javascript> alert('Cadastro inserido com sucesso!Você já pode fazer login!')</script>");
    echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/index.html'; </script>");
    }
    else
    {
    echo ("<script type=text/javascript> alert('Ops desculpe, aconteceu um erro do lado de cá! '".mysql_error().")</script>");
    echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/index.html'; </script>");
  
    }
    }
    echo ("<script type=text/javascript> alert('" + mysqlerror()+")</script>");
    echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/index.html'; </script>");
    
    mysql_close($conecta);
  ?>



