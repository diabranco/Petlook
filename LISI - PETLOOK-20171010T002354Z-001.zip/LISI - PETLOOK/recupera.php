<?php
    include("conexao.php");
    

    $telefone=mysql_real_escape_string(htmlspecialchars(trim($_GET["telefone"])));
    
    //echo($telefone);
    $query = mysql_query("select CAD_DONO_EMAIL,CAD_DONO_NOME,CAD_DONO_SENHA from `cad_dono` where `CAD_DONO_TEL`='$telefone';");
    $consulta=mysql_num_rows($query);
    $campo =mysql_fetch_array($query);

    $email = $campo["CAD_DONO_EMAIL"];
    $nome = $campo["CAD_DONO_NOME"];
    $senha= $campo["CAD_DONO_SENHA"];

    //echo($email."<br>");
    //echo($nome."<br>");
    //echo("<br>-->".$senha);
    
    if($consulta)
   {
   
    $headers = "From: suporte@petlook.net \r\n"."Reply-To: suporte@petlook.net \r\n"."X-Mailer: PHP/".phpversion()."\r\n"."MIME-Version: 1.0\r\n"."Content-Type: text/html; charset=utf8 \r\n";
  
    $mensagem = "<h1>Olá ".$nome."!</h1>Acesse o link de recuperação de senha: <br> <a href='http://www.petlook.iusti.com.br/novasenha.html e no campo código cole o seguinte valor: <strong>".$senha."</strong> ";
    $assunto = "Recuperação de senha de acesso ao PETLOOK";
    $para = $mail;

        if(mail($para, $assunto, nl2br($mensagem), $headers,"-f suporte@petlook.net"))
        {
      
        echo("<script type=text/javascript> alert('O link de recuperação de senha foi enviado para o email:".$email." !');</script>");   
        echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/login.html'; </script>"); 
       
        }
        else
        {

        echo("<script type=text/javascript> alert('Problema ao enviar email!Contate o suporte pelo email suporte@petlook.net!');</script>");
        echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/novasenha.html'; </script>"); 
        
        }

        
            
    }
    else
    {
        echo("<script type=text/javascript> alert('Usuário não encontrado no Petlook!Contate o suporte pelo email suporte@petlook.net!');</script>");
        echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/login.html'; </script>"); 

    }
            
    
    mysql_close($conecta);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        
    </body>
</html>
