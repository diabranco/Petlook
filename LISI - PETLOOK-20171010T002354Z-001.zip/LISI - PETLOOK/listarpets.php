<?php 
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);

include("conexao.php");
include("classpet.php");

$pet = new Pet;

$iddono = mysql_real_escape_string(htmlspecialchars(trim($_GET['iddono'])));

$retorno = json_encode($pet->retornapetsdono($iddono));


echo $retorno;



?>