<?php

include ("conexao.php");

    
class Pet {

    public $petid;
    public $petname;
    public $petdono;
    public $petespecie;
    public $petalimento;
    public $petnascimento;
    public $petsexo;
    public $racapet;
    public $petraiva;
    public $petV8;
    public $petv10;
    public $petleishimaniose;
    public $petgiardia;
    public $petoutrasvacinas;
    public $fot1;
    public $fot2;
    public $fot3;
    public $fot4;
    public $petdetalhe;
    public $petcolid;

    function retornaPet($idpet)
    {

        $query = mysql_query("select *  from `cad_pet` where `idCAD_PET`='$idpet';");
        $campo =mysql_fetch_array($query);

        $this -> petid = $idpet;
        $this-> petdono = $campo["CAD_IDDONO"];
        $this-> petname = $campo["NOMEPET"];
        $this-> petnascimento = $campo["NASCIMENTOPET"];
        $this-> petalimento = $campo["ALIMENTOPET"];
        $this-> petespecie = $campo["ESPECIEPET"]; 
        $this-> petsexo = $campo["SEXOPET"];
        $this-> racapet = $campo["RACAPET"];
        $this-> petraiva = $campo["RAIVAPET"];
        $this-> petV8 = $campo["V8PET"];
        $this-> petv10 = $campo["V10PET"];
        $this-> petleishimaniose = $campo["LEISHIMANIOSEPET"];
        $this-> petgiardia = $campo["GIARDIAPET"];
        $this-> petoutrasvacinas = $campo["OUTRASVACINASPET"];
        $this-> fot1 = $campo["FOT1"];
        $this-> fot2 = $campo["FOT2"];
        $this-> fot3 = $campo["FOT3"];
        $this-> fot4 = $campo["FOT4"];
        $this-> petdetalhe = $campo["DETALHEPET"];
        $this-> petcolid = $campo["IDCOLPET"];
        
    }

    function retornapetsdono($iddono)
    {
        
        $query = mysql_query("select *  from `cad_pet` where `CAD_IDDONO`='$iddono';");
        $campo =mysql_fetch_array($query);

        $num = mysql_num_rows($query);

        $petsdono = array();

        while($campo = mysql_fetch_assoc($query)){
          
        $pet = new Pet;

        $pet-> petid = $campo["idCAD_PET"];
        $pet-> petdono = $campo["CAD_IDDONO"];
        $pet-> petname = $campo["NOMEPET"];
        $pet-> petnascimento = $campo["NASCIMENTOPET"];
        $pet-> petalimento = $campo["ALIMENTOPET"];
        $pet-> petespecie = $campo["ESPECIEPET"]; 
        $pet-> petsexo = $campo["SEXOPET"];
        $pet-> racapet = $campo["RACAPET"];
        $pet-> petraiva = $campo["RAIVAPET"];
        $pet-> petV8 = $campo["V8PET"];
        $pet-> petv10 = $campo["V10PET"];
        $pet-> petleishimaniose = $campo["LEISHIMANIOSEPET"];
        $pet-> petgiardia = $campo["GIARDIAPET"];
        $pet-> petoutrasvacinas = $campo["OUTRASVACINASPET"];
        $pet-> fot1 = $campo["FOT1"];
        $pet-> fot2 = $campo["FOT2"];
        $pet-> fot3 = $campo["FOT3"];
        $pet-> fot4 = $campo["FOT4"];
        $pet-> petdetalhe = $campo["DETALHEPET"];
        $pet-> petcolid = $campo["IDCOLPET"];

        $petsdono[] = $pet;
        }

        
        return $petsdono;


        }

        function deletePet($idpet)
        {
          $query = mysql_query("delete from `cad_pet` where `idCAD_PET`='$idpet';");
          return($query);

        }

        




 }

   
    

?>

