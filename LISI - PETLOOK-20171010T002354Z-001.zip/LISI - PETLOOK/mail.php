<?php
$nome =  mysql_real_escape_string(htmlspecialchars(trim($_POST['nome']))); 
$telefone= mysql_real_escape_string(htmlspecialchars(trim($_POST['telefone'])));
$email  = mysql_real_escape_string(htmlspecialchars(trim($_POST['email'])));
$mensagem = mysql_real_escape_string(htmlspecialchars(trim($_POST['mensagem'])));
$emaildono = mysql_real_escape_string(htmlspecialchars(trim($_POST['emaildono'])));

$to      = $emaildono;
$subject = 'Seu Pet foi encontrado!';
$message = $mensagem;
$headers = 'From: '.$email.' . "\r\n" .
    'Reply-To:'.$email.' . "\r\n" .
    

mail($to, $subject, $message, $headers);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        
    </body>
</html>
