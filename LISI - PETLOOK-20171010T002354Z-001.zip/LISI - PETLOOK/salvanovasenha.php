<?php
 include("conexao.php");
    

    $cod=mysql_real_escape_string(htmlspecialchars(trim($_POST["codigo"])));
    $telefone = mysql_real_escape_string(htmlspecialchars(trim($_POST["telefone"])));
    $senha = md5($_POST["senha"]);
    
    //echo("cod: ".$cod);
    //echo("<br>telefone: ".$telefone);
    //echo("<br>senha: ".$senha);

    $idquery = mysql_query("select * from `cad_dono` where  `CAD_DONO_SENHA` = '$cod' and 
    `CAD_DONO_TEL`= '$telefone';"); 

    $campo =mysql_fetch_array($idquery);
    $id = $campo["idCAD_DONO"];
    $email = $campo["CAD_DONO_EMAIL"];
    $nome = $campo["CAD_DONO_NOME"];
    

    //echo("<br>Id:".$id);
       
   if($id)
   {
     //echo($id);
     
       $update = mysql_query("update `cad_dono` set `CAD_DONO_SENHA` = '$senha'  where  `idCAD_DONO`= '$id';"); 
       
       //echo($update);
       
        if($update)
        {
        echo("<script type=text/javascript> alert('Senha atualizada com sucesso!Você já pode fazer o login!')</script>");   
        echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/login.html';</script>"); 
       
        }else
        {
          echo("<script type=text/javascript> alert('Não foi possível atualizar sua senha, tente novamente por favor!')</script>");   
          echo("<script type=text/javascript>window.history.back();</script>"); 
        }

   }
   
   else
   {
        echo("<script type=text/javascript> alert('Código ou telefone não encontrados por favor verifique e tente novamente!');</script>");
        echo("<script type=text/javascript>window.history.back();</script>"); 
        
   }
      
    
    mysql_close($conecta);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        
    </body>
</html>
