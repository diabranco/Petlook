<?php 
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);

include("conexao.php");
include("classdono.php");



if (!empty($_GET['idcolpet'])){

$idcolpet = mysql_real_escape_string(htmlspecialchars(trim($_GET['idcolpet'])));

$query = mysql_query("select CAD_IDDONO  from `cad_pet` where `IDCOLPET`='$idcolpet';");
       
$campo = mysql_fetch_array($query);


$iddono = $campo["CAD_IDDONO"];


}

if (!empty($_GET['iddono'])){

$iddono = mysql_real_escape_string(htmlspecialchars(trim($_GET['iddono'])));

}


$dono = new dono;

$dono-> retornadono($iddono);

$retorno = json_encode($dono);

echo $retorno;

?>


