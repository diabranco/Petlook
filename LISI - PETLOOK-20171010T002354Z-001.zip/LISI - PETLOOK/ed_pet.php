<?php

?>

<?php
    include("conexao.php");
    //echo('cadastramento dos pets.');

    ini_set('display_errors',1);
    ini_set('display_startup_erros',1);
    error_reporting(E_ALL);
    
    $idpet=mysql_real_escape_string(htmlspecialchars(trim($_POST['idpet'])));
    $nomepet=mysql_real_escape_string(htmlspecialchars(trim($_POST['nomepet'])));
    $nascimento= $_POST['nascimento'];
    $especie = mysql_real_escape_string(htmlspecialchars(trim($_POST['especie'])));
    $sexo=mysql_real_escape_string(htmlspecialchars(trim($_POST['sexo'])));
    $raca =mysql_real_escape_string(htmlspecialchars(trim($_POST['raca'])));

        if(isset($_POST['raiva']))
    {
        $raiva =mysql_real_escape_string(htmlspecialchars(trim($_POST['raiva'])));
    }else { $raiva = NULL;}
   
     if(isset($_POST['v8']))
    {
       $v8 =mysql_real_escape_string(htmlspecialchars(trim($_POST['v8'])));
    }else {$v8 = NULL;}

     if(isset($_POST['v10']))
     {
         $v10 =mysql_real_escape_string(htmlspecialchars(trim($_POST['v10'])));
     }else {$v10 = NULL;}

       if(isset($_POST['leishimaniose']))
    {
        $leishimaniose =mysql_real_escape_string(htmlspecialchars(trim($_POST['leishimaniose'])));
    }else {$leishimaniose = NULL;}


    if(isset($_POST['giardia']))
    {
        $giardia =mysql_real_escape_string(htmlspecialchars(trim($_POST['giardia'])));
    }else{$giardia = NULL;}
  
    $fot1 =mysql_real_escape_string(htmlspecialchars(trim($_POST['fot1'])));
    $fot2 =mysql_real_escape_string(htmlspecialchars(trim($_POST['fot2'])));
    $fot3 =mysql_real_escape_string(htmlspecialchars(trim($_POST['fot3'])));
    $fot4 =mysql_real_escape_string(htmlspecialchars(trim($_POST['fot4'])));
    $detalhepet = mysql_real_escape_string(htmlspecialchars(trim($_POST['detalhepet'])));
    $outrasvacinas = mysql_real_escape_string(htmlspecialchars(trim($_POST['oustrasvacinas'])));

    $iddono = $_COOKIE['usupetlookserv'];

    $idcolpet = $iddono."X".$nomepet;

    $alimentopet = mysql_real_escape_string(htmlspecialchars(trim($_POST['alimento'])));
    
    
    $q = mysql_query("UPDATE `petlookdb`.`cad_pet` SET `NOMEPET`='$nomepet', `NASCIMENTOPET`='$nascimento', `ESPECIEPET`='$especie', `SEXOPET`='$sexo', `RACAPET`='$raca', `RAIVAPET`='$raiva', `V8PET`='$v8', `V10PET`='$v10', `LEISHIMANIOSEPET`='$leishimaniose', `GIARDIAPET`='$giardia', `OUTRASVACINASPET`='$outrasvacinas', `FOT1`='$fot1', `FOT2`='$fot2', `FOT3`='$fot3', `FOT4`='$fot4', `DETALHEPET`='$detalhepet',  `ALIMENTOPET`='$alimentopet' WHERE `idCAD_PET`='$idpet';");
    
    //echo($q);

    if($q)
    {
    $alerta = "Cadastro aletrado com sucesso! Insira na coleira do seu PET o identificador: ".$idcolpet;
    echo ("<script type=text/javascript> alert('Cadastro alterado com sucesso!');</script>");
    echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/cad_pet.html'; </script>");
    }
    else
    {
    echo ("não inseriu nada query:   ");
    echo("UPDATE `petlookdb`.`cad_pet` SET `NOMEPET`='$nomepet', `NASCIMENTOPET`='$nascimento', `ESPECIEPET`='$especie', `SEXOPET`='$sexo', `RACAPET`='$raca', `RAIVAPET`='$raiva', `V8PET`='$v8', `V10PET`='$v10', `LEISHIMANIOSEPET`='$leishimaniose', `GIARDIAPET`='$giardia', `OUTRASVACINASPET`='$outrasvacinas', `FOT1`='$fot1', `FOT2`='$fot2', `FOT3`='$fot3', `FOT4`='$fot4', `DETALHEPET`='$detalhepet',  `ALIMENTOPET`='$alimentopet' WHERE `idCAD_PET`='$idpet';");
    //echo ("<script type=text/javascript> alert('Ops desculpe, aconteceu um erro de cadastro, por favor tente novamente mais tarde. '".mysql_error().")</script>");
    //echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/index.html'; </script>");
    
    
  
    }
    

    
    mysql_close($conecta);
  ?>
