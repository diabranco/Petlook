<?php
    
include("conexao.php");

class dono
{
    public $name;
    public $email;
    public $tel; 
    public $cep ;
    public $rua ;
    public $no;
    public $bairro;
    public $estado;
    public $cidade ;
    public $senha;
    public $login;

    function retornadono($iddono)
    {
    $query = mysql_query("select *  from `cad_dono` where `idCAD_DONO`='$iddono';");
    $campo = mysql_fetch_array($query);

    $this-> name  = $campo["CAD_DONO_NOME"];
    $this-> email= $campo["CAD_DONO_EMAIL"];
    $this-> tel = $campo["CAD_DONO_TEL"];
    $this-> cep = $campo["CAD_DONO_CEP"];
    $this-> rua = $campo["CAD_DONO_RUA"];
    $this-> no= $campo["CAD_DONO_NUMERO"];
    $this-> bairro= $campo["CAD_DONO_BAIRRO"];
    $this-> estado= $campo["CAD_DONO_ESTADO"];
    $this-> cidade = $campo["CAD_DONO_CIDADE"];
    
    }

    function retordonocodigo($idcolpet)
    {
        
        $query = mysql_query("select CAD_IDDONO  from `cad_pet` where `IDCOLPET`='$idcolpet';");
       
        $campo = mysql_fetch_array($query);


        $iddono = $campo["CAD_IDDONO"];

        $dono = new dono;
        
        return $dono->retornadono($iddono);


     }


}

?>

