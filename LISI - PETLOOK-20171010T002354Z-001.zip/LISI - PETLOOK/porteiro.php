<?php

 $usuario = $_COOKIE['usupetlook'];
 //echo($usuario);

 if ($usuario)
 {}else
 {
     echo("<script type=text/javascript> alert('Realize o login para acessar os serviços do Petlook!');</script>");
     echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/login.html'; </script>"); 
 }


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        
    </body>
</html>
