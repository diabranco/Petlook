<?php
    include("conexao.php");
    

    
    $telefone=mysql_real_escape_string(htmlspecialchars(trim($_POST['telefone'])));
    $senha = md5($_POST['senha']);
   
    $query = mysql_query("select * from `cad_dono` where `CAD_DONO_TEL`='$telefone' AND `CAD_DONO_SENHA`= '$senha';");
    $login=mysql_num_rows($query);
    $campo =mysql_fetch_array($query);

    $usuarioid = $campo["idCAD_DONO"];
    $usuario = $campo["CAD_DONO_NOME"];
    

    //echo($query."<br>");
    //echo($login."<br>");
    //echo("usuario:".$usuario);
    
    if($login)
   {

    
    echo("<script type=text/javascript> alert('Bem vindo ao Petlook ".$usuario." !');</script>");
    echo("<script type=text/javascript> document.cookie='usepetlook=".$usuario.";</script>");
    echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/gerenciar_pets.html'; </script>"); 
    setcookie("usupetlook",$usuarioid,time() + (86400 * 365),"http://www.petlook.iusti.com.br/gerenciar_pets.html");
    setcookie("usupetlookserv",$usuarioid,time() + (86400 * 365));
    
    }
    else
    {
            
    echo("<script type=text/javascript> alert('Usuário não encontrado no Petlook!');</script>");
    echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/login.html'; </script>"); 
            
    }
            
    
    mysql_close($conecta);

  ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        
    </body>
</html>