,lghsa
<?php 
$conecta = mysql_connect("localhost", "iusticom_root", "amigo21@#") or print (mysql_error()); 
//print "Conexão OK!"; s
mysql_select_db("iusticom_petlookdb", $conecta) or print(mysql_error()); 
//print "Conexão e Seleção OK!"; 
//mysql_close($conecta);

 
?>
