<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        
    </body>
</html>


<?php
    
ini_set('display_errors',1);


ini_set('display_startup_erros',1);
error_reporting(E_ALL);

include("conexao.php");
include("classpet.php");

$pet = new Pet;

$idpet = mysql_real_escape_string(htmlspecialchars(trim($_GET['idpet'])));

if ($pet->deletePet($idpet))
{
   echo("<script type=text/javascript> alert('Pet excluído com sucesso !');</script>");  
   echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/gerenciar_pets.html'; </script>"); 
}else
{
   echo("<script type=text/javascript> alert('Problema na exclusão!');</script>");  
   echo("<script type=text/javascript>window.location.href = 'http://www.petlook.iusti.com.br/gerenciar_pets.html'; </script>"); 
}


?>


